/*** SyntaxHighlighter  3.0
 * Brush For Cobol
 *
 * 22.03.2011
 *
 * developer: George S.
 *
 **/

;(function()
{
	// CommonJS
	typeof(require) != 'undefined' ? SyntaxHighlighter = require('shCore').SyntaxHighlighter : null;

	function Brush()
	{

		var divisions =	'DIVISION IDENTIFICATION ENVIRONMENT DATA PROCEDURE ';

        var sections = 'SECTION CONFIGURATION INPUT-OUTPUT FILE CONTROL WORKING STORAGE LINKAGE ';

		var keywords =	'ABORT-TRANSACTION ABOUT ABS ACCEPT ACCESS ACTIVE-TIME ACTUAL ADD ' +
                        'ADDRESS ADVANCING AFTER ALL ALLOW ALLOWING ALPHABET ALPHABETIC ALPHABETIC-LOWER ' +
                        'ALPHABETIC-UPPER ALPHANUMERIC ALPHANUMERIC-EDITED ALSO ALTER ALTERNATE AND ANY ' +
                        'APPLY ARCTAN ARE AREA AREAS AS ASCENDING ASCII ASSIGN AT ATTACH ' +
                        'AUTHOR AUTO-SKIP AUXILIARY AWAIT BACKUP BEEP ' +
                        'BEFORE BEGIN-TRANSACTION BINARY ' +
                        'BIT-nn (nn=00 TO 23) BITS BLANK BLOCK ' +
                        'BOTTOM BY BZ CALL CANCEL CARD-PUNCH ' +
                        'CARD-READER CARD-READERS CASSETTE CASSETTES ' +
                        'CAUSE CD CF CH CHANGE CHANNEL CHANNEL-n (n=1 TO 7) ' +
                        'CHARACTER CHARACTERS CHECK CHECKPOINT CHEQUE ' +
                        'CLASS CLEAR CLOCK-UNITS CLOSE CMP CMP-1 COBOL ' +
                        'CODE CODE-SET COL COLLATING COLUMN COMMA  ' +
                        'COMMON COMMUNICATION COMP COMP-0 COMP-1 ' +
                        'COMP-2 COMP-3 COMP-4 COMP-5 COMPILE ' +
                        'COMPILETIME COMPUTATIONAL COMPUTATIONAL-0 ' +
                        'COMPUTATIONAL-1 COMPUTATIONAL-2 COMPUTATIONAL-3 COMPUTATIONAL-4 COMPUTATIONAL-5 ' +
                        'COMPUTE CONFIGURATION CONSOLE CONSTANT ' +
                        'CONTAINS CONTENT CONTINUE CONTROL ' +
                        'CONTROL-POINT CONTROLS CONVERSION CONVERTING ' +
                        'COPY CORE-EDS CORE-MT CORR CORRESPONDING ' +
                        'COS COUNT CP CREATE CRUNCH CURRENCY ' +
                        'CURRENT CURRENT-DATE CYLINDER ' +
                        'DATA DATABASE DATA-BASE-KEY DATA-BASE-RESTART ' +
                        'DATE DATE-COMPILED DATE-WRITTEN DAY ' +
                        'DAY-OF-WEEK DB DB-KEY DE DEALLOCATE ' +
                        'DEBUG-CONTENTS DEBUG-ITEM DEBUG-LENGTH ' +
                        'DEBUG-LINE DEBUG-NAME DEBUG-NUMERIC CONTENTS ' +
                        'DEBUG-SIZE DEBUG-START DEBUG-SUB DEBUG-SUB-1 ' +
                        'DEBUG-SUB-2 DEBUG-SUB-3 DEBUG-SUB-ITEM DEBUG-SUB-N ' +
                        'DEBUG-SUB-NUM DEBUGGING DEC DECIMAL-POINT ' +
                        'DECLARATIVES DECSYSTEM-10 DECSYSTEM-20 DECSYSTEM-30 ' +
                        'DEFERRED DELETE DELIMITED DELIMITER DENSITY ' +
                        'DEPENDING DEPTH DESCENDING DESTINATION ' +
                        'DETACH DETAIL DIGITS DIRECT DISABLE ' +
                        'DISALLOW DISC DISK DISKPACK DISKPACKS ' +
                        'DISPLAY DISPLAY-1 DISPLAY-2 DISPLAY-3 ' +
                        'DISPLAY-4 DISPLAY-5 DISPLAY-6 DISPLAY-7 DISPLAY-9 ' +
                        'DISPLAY-UNIT DIV DIVIDE DIVIDED DOWN DUMP ' +
                        'DUP DUPLICATE DUPLICATES DYNAMIC ECHO ' +
                        'EDS EDS-* EGI ELSE EMI EMPTY ENABLE ' +
                        'END END-ADD END-CALL END-COMPUTE END-DELETE END-DIVIDE ' +
                        'END-EVALUATE END-IF END-MULTIPLY END-OF-PAGE END-PERFORM ' +
                        'END-READ END-RECEIVE END-RETURN END-REWRITE END-SEARCH '  +
                        'END-START END-STRING END-SUBTRACT END-TRANSACTION ' +
                        'END-UNSTRING END-WRITE ENDING ENTER ENTRY ENVIRONMENT '  +
                        'EOP EPI EQUAL EQUALS ERASE ERROR ESI EVALUATE EVEN '  +
                        'EVENT EVERY EXAMINE EXCEEDS EXCEPTION EXCHANGE ' +
                        'EXCL EXCLUSIVE EXECUTE EXHIBIT EXIT EXP EXPONENTIATED ' +
                        'EXTEND EXTERNAL FALSE FD FDS FDS-* FILE FILE-CONTROL ' +
                        'FILE-ID FILE-LIMIT FILE-LIMITS FILE-MESSAGES FILE-STATUS '  +
                        'FILLER FINAL FIND FIRST FIRST-LEVEL FIRSTONE FLOAT '  +
                        'FOOTING FOR FORTRAN FORTRAN-IV FREE FREED FROM ' +
                        'GENERATE GENERATION-NO GET GIVING GLOBAL GO '  +
                        'GOBACK GREATER GROUP HANDY-KEYS HEADING HERE ' +
                        'HIGH-VALUE HIGH-VALUES I-O I-O-CONTROL ID IDENTIFICATION ' +
                        'IF IN INDEX INDEX-BUFFER INDEXED INDICATE INITIAL INITIALIZE ' +
                        'INITIATE INPUT INPUT-OUTPUT INQUIRY INSERT INSPECT INSTALLATION '  +
                        'INTERCHANGE INTERRUPT INTO INVALID INVOKE IS JOURNAL JUST JUSTIFIED '  +
                        'KEY KEYBOARD KEYS LABEL LAST LD LEADING LEAVING LEFT LEFT-JUSTIFY ' +
                        'LENGTH LENGTH-CHECK LESS LIBRARY LIKE LIMIT LIMITS LIN ' +
                        'LINAGE LINAGE-COUNTER LINE LINE-COUNTER LINES LINKAGE LN LOCAL ' +
                        'LOCAL-STORAGE LOCATION LOCK LOCKED LOW-VALUE LOW-VALUES LOWER-BOUND LOWER-BOUNDS ' +
                        'MACRO MAX MCF MCF-* MEMBER MEMORY MERGE MESSAGE MESSAGE-PRINTER MIN MOD MODE ' +
                        'MODIFIED MODIFY MODULES MONITOR MOVE MULTIPLE MULTIPLE-I-O MULTIPLIED '  +
                        'MULTIPLY MYSELF NATIVE NEGATIVE NEXT NO NOMINAL NON-STANDARD NONE NOT '  +
                        'NOTE NULL NUMBER NUMERIC NUMERIC-EDITED OBJECT-COMPUTER OBJECT-PROGRAM '  +
                        'OC OCCURS ODD OF OFF OMITTED ON ONES ONLY OPEN OPT OPTIONAL OR ORDER '  +
                        'ORGANISATION ORGANIZATION OTHER OTHERS OTHERWISE OUTPUT OVERFLOW OWN OWNER '  +
                        'PADDING PAGE PAGE-COUNTER PAPER-PUNCH PAPER-READER PAPER-TAPE-PUNCH PAPER-TAPE-READER ' +
                        'PARITY PDP-10 PERFORM PETAPE PF PH PIC PICTURE PLACES PLUS POINT POINTER ' +
                        'POSITION POSITIONING POSITIVE PREPARED PRINTER PRINTERS PRINTING ' +
                        'PRIOR PRIORITY PRIVACY PROCEDURE PROCEDURES PROCEED PROCESS PROCESSING '  +
                        'PROGRAM PROGRAM-ID PROMPT PROT PROTECT PROTECTED PUNCH PURGE QUEUE QUOTE QUOTES '  +
                        'RANDOM RANGE RD READ READ-REWRITE READ-WRITE READER READERS READY RECEIVE RECEIVED '  +
                        'RECORD RECORDING RECORDS RECREATE REDEFINES REEL REEL-NUMBER REF REFERENCE REFERENCE-MODIFIER ' +
                        'REFERENCES RELATIVE RELEASE REMAINDER REMARKS REMOTE REMOVAL REMOVE RENAMES REPLACE '  +
                        'REPLACING REPORT REPORTING REPORTS RERUN RESERVE RESET RESTART RETAIN RETAINED RETR '   +
                        'RETRIEVAL RETURN REVERSED REWIND REWRITE RF RH RIGHT RIGHT-JUSTIFY ROUNDED RUN RUN-UNIT ' +
                        'SAME SAVE-FACTOR SCHEMA SD SEARCH SECOND-LEVEL SECURITY SEEK SEGMENT SEGMENT-LIMIT ' +
                        'SELECT SELECTIVE SEND SENTENCE SENTINEL-PROCESSING SEPARATE SEQUENCE SEQUENCED ' +
                        'SEQUENTIAL SET SETS SIGN SIGNED SIN SINGLE SIXBIT SIZE SN SORT SORT-* SORT-MERGE ' +
                        'SOURCE SOURCE-COMPUTER SPACE SPACE-FILL SPACES SPECIAL-NAMES SPO SQRT STANDARD ' +
                        'STANDARD-1 STANDARD-2 STANDARD-ASCII START STATUS STOP STORE STRING SUB-QUEUE-1 ' +
                        'SUB-QUEUE-2 SUB-QUEUE-3 SUB-SCHEMA SUBTRACT SUM SUPERVISOR SUPPRESS SUSPEND SWITCH ' +
                        'SYMBOLIC SYNC SYNCHRONISED SYNCHRONIZED SYSTEM SZ '  +
                        'TABLE TALLY TALLYING TAPE TAPE-* TAPE7 TAPE9 TAPES TERMINAL TERMINATE TEST TEXT ' +
                        'THAN THEN THROUGH THRU TIME TIMES TO TODAY TODAYS-DATE TOP TRACE TRAILING-SIGN ' +
                        'TRAILLING TRANSFER-REPLY TRUE TYPE TYPEWRITER ' +
                        'UNAVAILABLE UNEQUAL UNIT UNLOCK UNSTRING UNTIL UP UPDATE UPDATES UPON UPPER-BOUND ' +
                        'UPPER-BOUNDS USAGE USAGE-MODE USE USER-NUMBER USER-SENTINEL USING ' +
                        'VA VALUE VALUES VARYING VERB '  +
                        'WAIT WHEN WITH WITHIN WORDS WORKING-STORAGE WRITE ' +
                        'ZERO ZERO-FILL ZEROS ZEROES ' ;




		this.regexList = [
			{ regex: /^[*].+/gm,    css: 'comments' },      // one line comments
		   	{ regex: SyntaxHighlighter.regexLib.doubleQuotedString,		css: 'color2' },			// strings
			{ regex: SyntaxHighlighter.regexLib.singleQuotedString,		css: 'color2' },			// strings
			{ regex: new RegExp(this.getKeywords(divisions), 'gm'),		css: 'string bold' },
			{ regex: new RegExp(this.getKeywords(sections), 'gm'),		css: 'color3 bold' },
			{ regex: new RegExp(this.getKeywords(keywords), 'gm'),		css: 'keyword bold' }
            			];
	};

	Brush.prototype	= new SyntaxHighlighter.Highlighter();
	Brush.aliases	= ['cobol'];

	SyntaxHighlighter.brushes.Cobol = Brush;

	// CommonJS
	typeof(exports) != 'undefined' ? exports.Brush = Brush : null;
})();
